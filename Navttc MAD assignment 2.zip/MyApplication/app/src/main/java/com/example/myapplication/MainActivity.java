package com.example.myapplication;

import android.os.Bundle;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<Country> countryList;
    CountryAdapter adapter;

    int[] flagImages = {
            R.drawable.pakistan,
            R.drawable.usa,
            R.drawable.india,
            R.drawable.china,
            R.drawable.germany,
            R.drawable.newzealand,

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.countryListView);
        countryList = new ArrayList<>();

        String[] countryNames = getResources().getStringArray(R.array.country_names);

        for (int i = 0; i < countryNames.length; i++) {
            countryList.add(new Country(countryNames[i], flagImages[i]));
        }

        adapter = new CountryAdapter(this, countryList);
        listView.setAdapter(adapter);
    }
}